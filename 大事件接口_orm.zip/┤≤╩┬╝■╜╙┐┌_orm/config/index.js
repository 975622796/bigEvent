module.exports ={
    // 库名
    database:'bignews',
    // 用户名
    username:'root',
    // 密码
    password:'root',
    // 主机
    host:'127.0.0.1',
    // 接口基地址
    baseUrl:'http://localhost:8080'
}